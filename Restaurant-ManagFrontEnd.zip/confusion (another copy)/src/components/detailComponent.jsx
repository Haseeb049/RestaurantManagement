import React from "react";
import {
  Card,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  BreadcrumbItem,
  Breadcrumb
} from "reactstrap";
import { Link } from "react-router-dom";
import Comment from "./commentForm";
import { Loading } from "./loadingComponent";
import { baseUrl } from "../shared/baseUrl";
import { FadeTransform, Fade, Stagger } from "react-animation-components";
const RenderDish = ({ dish }) => {
  return (
    <FadeTransform
      in
      transformProps={{
        exitTransform: "scale(0.5) translateY(-50%)"
      }}
    >
      <Card>
        <CardImg src={baseUrl + dish.image} alt={dish.nam} />
        <CardBody>
          <CardTitle>{dish.name}</CardTitle>
          <CardText>{dish.description}</CardText>
        </CardBody>
      </Card>
    </FadeTransform>
  );
};
const RenderComments = ({ comments, postComment, dishId }) => {
  return (
    <Card className="border-0">
      <CardBody>
        <CardTitle>
          <h4>Comments</h4>
        </CardTitle>
        <Stagger in>
          {comments.map(comment => {
            return (
              <Fade in>
                <CardText key={comment.id}>
                  <div className="column">
                    <div>{comment.comment}</div>
                    <div>
                      <span>--</span>
                      {comment.author}{" "}
                      <span>
                        ,{" "}
                        {new Intl.DateTimeFormat("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "2-digit"
                        }).format(new Date(Date.parse(comment.date)))}
                      </span>
                    </div>
                  </div>
                </CardText>
              </Fade>
            );
          })}
        </Stagger>
        <Comment dishId={dishId} postComment={postComment} />
      </CardBody>
    </Card>
  );
};
const DishDetails = props => {
  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.dish != null) {
    return (
      <div className="container">
        <div className="row">
          <Breadcrumb>
            <BreadcrumbItem>
              <Link to="/menu">Menu</Link>
            </BreadcrumbItem>
            <BreadcrumbItem active>{props.dish.name}</BreadcrumbItem>
          </Breadcrumb>
          <div className="col-12">
            <h3>{props.dish.name}</h3>
            <hr />
          </div>
        </div>
        <div className="row">
          <div className="col-12 col-md-5 m-1">
            <RenderDish dish={props.dish} />
          </div>
          <div className="col-12 col-md-5 m-1">
            <RenderComments
              comments={props.comments}
              postComment={props.postComment}
              dishId={props.dish.id}
            />
          </div>
        </div>
      </div>
    );
  } else {
    return <div></div>;
  }
};

export default DishDetails;
