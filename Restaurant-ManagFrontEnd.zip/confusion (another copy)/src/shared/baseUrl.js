export const baseUrl = "http://localhost:3001/";
